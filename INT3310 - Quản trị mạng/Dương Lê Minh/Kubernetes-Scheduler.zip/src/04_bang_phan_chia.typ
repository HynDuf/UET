#{
  show heading: none
  heading(numbering: none)[Bảng phân chia công việc]
}
#align(center, text(13pt, strong("BẢNG PHÂN CHIA CÔNG VIỆC")))
#v(0.2cm)

#table(
  columns: (auto, auto, auto),
  inset: 12pt,
  align: (center + horizon, horizon, center + horizon),
  table.header([*Thành viên*],  table.cell(align: center)[*Nhiệm vụ*], [*Đóng \ góp*]),
  [Huỳnh Tiến Dũng\ (Nhóm trưởng) \ 21020007], [- Lập kế hoạch, phân công công việc cho nhóm.
  - Tìm hiểu và cài đặt trình lập lịch custom. Trình bày phần Demo (Chương 3).
  - Chỉnh sửa slide.
  - Đại diện nhóm thuyết trình.], [27%],
  [Vũ Huy Hoàng\ 22021108], [- Tìm hiểu và trình bày về trình lập lịch Kubernetes (Chương 2).], [17%],
  [Nguyễn Đăng Quân\ 22021121], [- Tìm hiểu vấn đề thực tế với Kubernetes, trình bày giới thiệu bài toán (Chương 1).
  - Hỗ trợ cài đặt trình lập lịch custom, lồng tiếng phần Demo.
  - Đại diện nhóm thuyết trình. ], [25%],
  [Nguyễn Hồng Quân\ 22021122], [- Tìm hiểu và trình bày về trình lập lịch Kubernetes (Chương 2).], [15%],
  [Nguyễn Chí Thanh\ 22021123], [- Lên kế hoạch bố cục và chuẩn bị nội dung slide từ quyển báo cáo.], [16%],
)

#pagebreak()
