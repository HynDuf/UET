#import "/template.typ" : *

#[
  #set heading(numbering: "Chương 1.1")
  = Demo <chuong4>
]
Video demo hoàn chỉnh được đăng tải tại #link("https://github.com/HynDuf/custom-kubernetes-scheduler/blob/master/demo_final.mp4")[Github - Custom Kubernetes Scheduler Demo]. Những lệnh dùng để chạy demo được đăng tải tại #link("https://github.com/HynDuf/custom-kubernetes-scheduler/blob/master/DEMO.md")[Github - DEMO.md].
== Set up Google Kubernetes Engine (GKE)

Thực hiện cài đặt GKE theo các bước bên dưới

#figure(
  image("../images/demo/google-cloud.png"),
  caption: [Màn hình Google Cloud]
)

#figure(
  image("../images/demo/project.png"),
  caption: [Lựa chọn dự án]
)
#figure(
  image("../images/demo/cluster.png"),
  caption: [Truy cập vào dịch vụ cluster của GKE]
)

#figure(
  image("../images/demo/kubernetes-api.png"),
  caption: [Bật API Kubernetes]
)

#figure(
  image("../images/demo/create-cluster.png"),
  caption: [Tạo cluster mới]
)

#figure(
  image("../images/demo/setup-cluster.png"),
  caption: [Thiết lập Cluster]
)

#figure(
  image("../images/demo/connect-1.png"),
  caption: [Thiết lập kết nối đến master]
)

#figure(
  image("../images/demo/connect-2.png"),
  caption: [Lấy mã kết nối]
)

#figure(
  image("../images/demo/cloud-shell.png"),
  caption: [Truy cập bằng Google Cloud Shell]
)

Thực hiện các bước sau trên Google Cloud Shell để clone dự án trình lập lịch tùy chỉnh và build và push image Docker tương ứng của trình lập lịch lên registry của Google Cloud.

```sh
# Clone the custom scheduler repository (or your fork)
git clone https://github.com/HynDuf/custom-kubernetes-scheduler.git
cd custom-kubernetes-scheduler

# --- Build and Push Custom Scheduler Docker Image ---
cd scheduler
# The following commands build and push the scheduler image to Google Container Registry (GCR).
# Ensure PROJECT_ID is correctly captured from your gcloud config.
PROJECT_ID=$(gcloud config get-value project)
docker build -t "gcr.io/${PROJECT_ID}/custom-scheduler:v1" .
gcloud auth configure-docker gcr.io --quiet # Authenticate Docker with GCR
docker push "gcr.io/${PROJECT_ID}/custom-scheduler:v1"
cd ..
```

Sau đó chỉnh lại đường dẫn của image custom scheduler trong tệp manifest `scheduler/custom-scheduler-deployment.yaml` tương ứng với đường dẫn image ở bên trên.

Tiếp đến, tạo namespace `monitoring` và chạy cái Pods liên quan tới Prometheus và Node Exporter để truy xuất dữ liệu của các nodes:

```sh
# --- Deploy Monitoring Components (Prometheus & Node Exporter) ---
# Create a dedicated namespace for monitoring components
kubectl create namespace monitoring

# Deploy Node Exporter (collects hardware and OS metrics from each node)
kubectl apply -f node-exporter/node-exporter-daemonset.yml

# Deploy Prometheus (monitoring system and time series database)
# This includes RBAC, ConfigMap, Deployment, and Service for Prometheus
kubectl apply -f prometheus/clusterRole.yaml
kubectl apply -f prometheus/config-map.yaml -n monitoring
kubectl apply -f prometheus/prometheus-deployment.yaml -n monitoring
kubectl apply -f prometheus/prometheus-service.yaml -n monitoring

# Verify monitoring components are running
kubectl get pods -o wide -n monitoring
# You should see one `node-exporter-*` p
```

#figure(
  image("../images/demo/demo-1.png"),
  caption: [Sau khi chạy cái Pods liên quan tới Prometheus và Node Exporter]
)

Truy cập vào Web UI của Prometheus ta sẽ thấy giao diện và thử truy vấn bộ nhớ còn lại của 3 máy.

#figure(
  image("../images/demo/demo-2.png"),
  caption: [Web UI của Prometheus]
)

Sau đó, ta sẽ deploy trình lập lịch tùy chỉnh như sau:

```sh 
# --- Deploy the Custom Scheduler ---
# Apply RBAC rules for the custom scheduler
kubectl apply -f scheduler/scheduler-rbac.yaml
# Deploy the custom scheduler itself (ensure you've updated the image name in this YAML)
kubectl apply -f scheduler/custom-scheduler-deployment.yaml

# --- Watch Custom Scheduler Logs ---
kubectl logs -n kube-system -l app=custom-scheduler -f --tail=100
```

#figure(
  image("../images/demo/demo-3.png"),
  caption: [Xem logs của trình lập lịch tùy chỉnh sau khi vừa deploy]
)

== Default Scheduler vs Custom Scheduler

Sau khi cài đặt thành công thì ta sẽ test 2 trình lập lịch như sau. Ta có `sleep.yaml` sẽ tạo ra 2 Pods yêu cầu 1600Mi bộ nhớ nhưng thật ra không hề sử dụng bộ nhớ, còn `sysbench.yaml` sẽ yêu cầu 0Mi nhưng thực chất lại sử dụng lên đến 2Gib bộ nhớ của node.

```sh 
# --- Demo: Resource-Aware Scheduling ---
# This demo highlights how the custom scheduler considers actual resource usage,
# unlike the default scheduler which primarily looks at resource requests.

# Deploy 'sleep.yaml': Requests 1600Mi Memory, but actually uses very little.
# Deploy 'sysbench.yaml': Requests 0Mi Memory, but actually consumes nearly 2GiB of Memory.
kubectl apply -f scheduler/deployments/sleep.yaml
kubectl apply -f scheduler/deployments/sysbench.yaml

# Wait for these pods to be scheduled and running.
# Check their status and on which nodes they are placed:
kubectl get pods -o wide
```

#figure(
  image("../images/demo/demo-4.png"),
  caption: [2 nodes chạy 2 pods `sleep.yaml` và 1 node còn lại chạy pod `sysbench.yaml`]
)

#figure(
  image("../images/demo/demo-5.png"),
  caption: [Node chạy `sysbench.yaml` có lượng memory requested thấp]
)

#figure(
  image("../images/demo/demo-6.png"),
  caption: [Node chạy `sleep.yaml` có lượng memory requested cao]
)

Tuy vậy, nodes chạy `sleep.yaml` lại có memory trống cao hơn nhiều so với node chạy `sysbench.yaml`.

#figure(
  image("../images/demo/demo-7.png"),
  caption: [Thực tế lượng memory trống của các node]
)

Sau đó, ta thử deploy `testdefault.yaml` (sử dụng default scheduler) và `testcustom.yaml` (sử dụng scheduler custom của nhóm).

#figure(
  image("../images/demo/demo-8.png"),
  caption: [`testdefault.yaml` được chạy trên máy chạy `sysbench.yaml` (mặc dù máy này đang có rất ít memory trống), còn `testcustom.yaml` được chạy trên máy chạy `sleep.yaml` (máy đang có gần như toàn bộ memory trống)]
)

Xem logs của custom scheduler ta sẽ thấy 3 máy được đánh điểm só như thế nào. Để ý rằng máy chạy `sysbench.yaml` có điểm memory và CPU rất thấp nên scheduler đã chọn máy chạy `sleep.yaml` có điểm số cao hơn nhiều.

#figure(
  image("../images/demo/demo-9.png"),
  caption: [Logs của custom scheduler]
)
== Node Selector

Ngoài ra, custom scheduler của nhóm còn có tính năng lập lịch dựa trên node có label cụ thể.

```sh 
# --- Demo: Node Selector ---
# Label a node (replace [CHOSEN_NODE_FOR_LABEL] with an actual node name from `kubectl get nodes`):
kubectl label node [CHOSEN_NODE_FOR_LABEL] group=red --overwrite

# Deploy a pod that uses a nodeSelector to target the labeled node:
kubectl apply -f scheduler/deployments/pod-node-selector-1.yaml
# Check pod placement and custom scheduler logs:
kubectl get pods -o wide
kubectl logs -n kube-system -l app=custom-scheduler -f --tail=100
```

Khi xem logs, ta sẽ thấy chỉ tìm được 1 node thỏa mãn label `group=red`.

#figure(
  image("../images/demo/demo-10.png"),
  caption: [Logs của custom scheduler]
)

== Taint and Tolerants
Custom scheduler của nhóm cũng có tính năng lập lịch dựa taints và tolerations.

```sh 
# --- Demo: Taints and Tolerations ---
# Taint two different nodes (replace placeholders with actual node names from `kubectl get nodes`):
kubectl taint nodes [CHOSEN_NODE_1_FOR_TAINT] key1=value1:NoSchedule --overwrite
kubectl taint nodes [CHOSEN_NODE_2_FOR_TAINT] key2=value2:NoSchedule --overwrite

# Deploy 'pod-toleration-1.yaml'. This pod only tolerates 'key1=value1:NoSchedule'.
# It should be scheduled on [CHOSEN_NODE_1_FOR_TAINT] or the remaining node.
# [CHOSEN_NODE_2_FOR_TAINT] will not pass the predicate check because the pod doesn't tolerate its taint.
kubectl apply -f scheduler/deployments/pod-toleration-1.yaml
```

Khi xem logs, ta sẽ thấy chỉ tìm được 2 node thỏa mãn, là node có taint `key1=value1` và node không có taint nào.

#figure(
  image("../images/demo/demo-11.png"),
  caption: [Logs của custom scheduler]
)
== Node Affinity

Ngoài ra, điểm số của mỗi node cũng được ưu tiên dựa trên node affinity. Ở đây ta sẽ đánh dấu 2 node, một node `zone=a` (được ưu tiên `weight=80` và node `zone=b` được ưu tiên `weight=20`).

```sh 
# --- Demo: Node Affinity ---
# Label two different nodes (replace placeholders with actual node names from `kubectl get nodes`):
kubectl label node [CHOSEN_NODE_1_FOR_AFFINITY_LABEL] zone=a
kubectl label node [CHOSEN_NODE_2_FOR_AFFINITY_LABEL] zone=b

# Deploy 'pod-preferred-affinity.yaml'. This pod has a preferredNodeSchedulingIgnoredDuringExecution
# affinity for nodes with label 'zone=a' (weight: 80) or 'zone=b' (weight: 20).
kubectl apply -f scheduler/deployments/pod-preferred-affinity.yaml
```

Ta sẽ thấy node có `zone=a` được tăng thêm điểm Affinity là 8 và node có `zone=b` được tăng thêm điểm Affinity là 2.

#figure(
  image("../images/demo/demo-12.png"),
  caption: [Logs của custom scheduler]
)

